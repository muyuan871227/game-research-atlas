import {chromium} from 'playwright';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {drop} from '../assets/scripts/GameLogic.ts';
const out=new URL('.',import.meta.url).pathname;
const b=await chromium.launch({headless:true,args:['--no-sandbox']});const p=await b.newPage({viewport:{width:405,height:720},deviceScaleFactor:1});const errors=[];p.on('pageerror',e=>errors.push(e.message));const report={input:'real Playwright mouse.click/touchscreen.tap; read-only snapshot bridge; no injected game state',runs:[],errors};
async function start(query=''){await p.goto('http://127.0.0.1:18973/index.html'+query);await p.waitForFunction(()=>globalThis.__STAR_ISLE__,{timeout:30000});await p.waitForTimeout(350);return p.evaluate(()=>__STAR_ISLE__.snapshot());}
const get=()=>p.evaluate(()=>__STAR_ISLE__.snapshot());
await start();await p.screenshot({path:out+'initial.png'});
for(const [kind,query]of [['default',''],['win','?moves=80&goal=64&theme=garden&title=微光花园'],['loss','?moves=15&goal=512']]){
 let snap=await start(query);const steps=[];
 for(let i=0;i<85&&snap.state.status==='playing';i++){
 const options=[];for(let c=0;c<4;c++){const clone=structuredClone(snap.state),result=drop(clone,c,snap.config,()=>0);if(result.accepted)options.push({c,result,clone});}
 options.sort((a,b)=>kind==='loss'?a.result.gain-b.result.gain:b.result.gain-a.result.gain||a.clone.grid[a.c].filter(Boolean).length-b.clone.grid[b.c].filter(Boolean).length);
 const choice=options[0];assert.ok(choice);const before=snap;await p.mouse.click(81+choice.c*81,360);await p.waitForTimeout(220);snap=await get();assert.equal(snap.state.turns,before.state.turns+1);assert.equal(snap.state.moves,before.state.moves-1);assert.equal(snap.state.score,choice.clone.score);assert.deepEqual(snap.state.grid,choice.clone.grid);steps.push({col:choice.c,next:before.state.next,score:snap.state.score,moves:snap.state.moves});
 }
 if(kind==='win')assert.equal(snap.state.status,'won');if(kind==='loss')assert.equal(snap.state.status,'lost');assert.notEqual(snap.state.status,'playing');await p.screenshot({path:out+kind+'-settled.png'});const final=structuredClone(snap);await p.mouse.click(81,360);await p.waitForTimeout(220);assert.deepEqual((await get()).state,final.state);await p.mouse.click(202,651);await p.waitForTimeout(220);snap=await get();assert.equal(snap.state.score,0);assert.equal(snap.state.turns,0);assert.equal(snap.state.moves,snap.config.moves);assert.ok(snap.state.grid.flat().every(x=>x===0));report.runs.push({kind,config:final.config,status:final.state.status,steps,terminalInputBlocked:true,restartPassed:true});
}
let snap=await start('?moves=14&goal=65&theme=unknown&title=%3Ctest%3E');assert.equal(snap.config.moves,40);assert.equal(snap.config.goal,256);assert.equal(snap.config.theme,'orbit');assert.equal(snap.config.title,'test');report.invalidQueryFallback=true;
const mobile=await b.newPage({viewport:{width:360,height:640},hasTouch:true,isMobile:true});await mobile.goto('http://127.0.0.1:18973/index.html');await mobile.waitForFunction(()=>globalThis.__STAR_ISLE__);await mobile.touchscreen.tap(72,320);await mobile.waitForTimeout(250);assert.equal((await mobile.evaluate(()=>__STAR_ISLE__.snapshot())).state.turns,1);report.mobileTouch=true;await mobile.screenshot({path:out+'mobile-touch.png'});
assert.deepEqual(errors,[]);await writeFile(out+'browser-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify({runs:report.runs.map(r=>({kind:r.kind,status:r.status,clicks:r.steps.length,score:r.steps.at(-1).score})),pageErrors:errors.length,mobileTouch:report.mobileTouch}));await b.close();
