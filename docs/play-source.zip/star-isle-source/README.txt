星屿合成 — original Cocos Creator 3.8.8 prototype

Gameplay: four columns, five rows. Click a non-full column to drop the preview 2/4 tile. The active tile merges one equal neighbour in down/left/right/up priority, doubles and scores its new value. Apply column gravity after every merge; track the active tile and continue chains. Reaching goal wins before checking exhausted moves or full board. Terminal games reject drops. Restart clears score and board.

Query parameters: title (sanitized, max 24 characters), theme=orbit|garden, moves=15..80 integer (default 40), goal=64|128|256|512 (default 256). Orbit is dark blue with star dots; garden is dark green. Both use original geometric numeric tiles.

Build: install Cocos Creator 3.8.8; run node scripts/export.mjs --project <absolute-project-path>. COCOS_CREATOR may point to the installed editor. The build produces multi-file dist/. Run node scripts/serve.mjs dist --port 8099. Serve every asset together, including relative paths and licenses.

Test: node --test qa/logic.test.mjs. Playwright is needed for scripts/selftest.mjs and browser QA. qa/browser.mjs uses a localhost test server on port 18973, actual clicks/touch taps, and read-only state snapshots. No injected game state is used. Install dependencies using Bun if needed. Browser QA paths in source are developer tooling, not public game assets.

This source package excludes editor caches, logs, node_modules, dist, remote model generation scripts and paid evaluation scripts. No external artwork is used. Scaffold and Cocos runtime MIT notices plus engine third-party licenses are retained. This is a local prototype, not a release or evidence of retention/revenue. Local compute cost is unknown; added paid-model calls and charges were zero.
