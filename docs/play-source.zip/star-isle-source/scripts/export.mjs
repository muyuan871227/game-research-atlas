#!/usr/bin/env node
// ──────────────────────────────────────────────────────────────────────────
// export.mjs — clikit Cocos Creator build = headless web-mobile export.
//
// Replaces the Vite single-file build the JS engines use. A Cocos Creator
// web-mobile build is MULTI-FILE (index.html + cocos-js bundle + system bundle
// + settings JSON + assets/ + optional wasm physics blob), produced by the
// CocosCreator EDITOR binary in headless `--build` mode. This script:
//   1. locates the CocosCreator binary (PATH, /Applications/Cocos*, env),
//   2. if found, runs:
//        CocosCreator --project <dir> --build "platform=web-mobile;debug=false"
//      and reports the multi-file output under dist/,
//   3. if NOT found, prints a BUILD-BLOCKED message with the EXACT command and
//      exits 3 (distinct from a code error). Cocos is an editor-centric engine
//      — unlike Godot (which happened to be installed), the editor is a ~2GB
//      download and is frequently absent. Code-complete + build-blocked is a
//      VALID, honest outcome: the TS game code + scene + scripts are all real;
//      only the editor toolchain that compiles them is missing.
//
// Usage (from a stamped template dir, project files at the dir root):
//   node scripts/export.mjs              # release web-mobile build → dist/
//   node scripts/export.mjs --debug      # debug build (faster, larger)
//   node scripts/export.mjs --project .  # explicit project dir
// ──────────────────────────────────────────────────────────────────────────
import { existsSync, mkdirSync, readdirSync, statSync, rmSync, renameSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync, execSync } from 'node:child_process';
import { homedir } from 'node:os';

const __dirname = dirname(fileURLToPath(import.meta.url));

function resolveProjectDir() {
  const i = process.argv.indexOf('--project');
  if (i !== -1 && process.argv[i + 1]) return resolve(process.argv[i + 1]);
  return resolve(__dirname, '..');
}

// Find the CocosCreator editor binary. Cocos Creator installs under
// /Applications/Cocos/Creator/<version>/CocosCreator.app on macOS (via the
// Cocos Dashboard), or a standalone /Applications/CocosCreator.app. The inner
// binary is .../Contents/MacOS/CocosCreator.
function findCocos() {
  if (process.env.COCOS_CREATOR && existsSync(process.env.COCOS_CREATOR)) return process.env.COCOS_CREATOR;
  // PATH
  try {
    const p = execSync('command -v CocosCreator cocos 2>/dev/null || true', { encoding: 'utf8' })
      .trim()
      .split('\n')[0];
    if (p && existsSync(p)) return p;
  } catch {
    /* */
  }
  // macOS app bundles — glob the Dashboard install location for any version.
  const roots = [];
  try {
    const dash = '/Applications/Cocos/Creator';
    if (existsSync(dash)) {
      for (const v of readdirSync(dash)) {
        roots.push(join(dash, v, 'CocosCreator.app', 'Contents', 'MacOS', 'CocosCreator'));
      }
    }
  } catch {
    /* */
  }
  roots.push(
    '/Applications/CocosCreator.app/Contents/MacOS/CocosCreator',
    join(homedir(), 'Applications', 'CocosCreator.app', 'Contents', 'MacOS', 'CocosCreator'),
  );
  // newest version first
  roots.sort().reverse();
  for (const c of roots) if (existsSync(c)) return c;
  return null;
}

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

// Kill ONLY the build editor's own process group — not every CocosCreator on the
// machine (the user may have the GUI editor open for other work). Requires the
// child to be spawned `detached:true` so it leads its own group.
function killBuildGroup(child) {
  if (!child || !child.pid) return;
  try { process.kill(-child.pid, 'SIGTERM'); } catch { try { child.kill('SIGTERM'); } catch { /* */ } }
  setTimeout(() => { try { process.kill(-child.pid, 'SIGKILL'); } catch { /* */ } }, 1500);
}

// Run the headless Cocos build WITHOUT deadlocking on the editor that won't exit.
// KNOWN HANG: Cocos Creator finishes the build (writes web-mobile/index.html) but
// the Electron editor / metric collector lingers idle forever, so a blocking
// spawnSync waits indefinitely — this is what froze the weekly engine-evolve
// routine for ~5h until the session reaper killed it. Strategy: spawn non-blocking
// and watch for the artifact to appear and stop growing; once stable, the build is
// done, so kill the idle editor and continue. Returns an `r`-like { status }.
async function runBuildWithWatchdog(bin, args, platformDir) {
  const ARTIFACT = join(platformDir, 'index.html');
  const POLL_MS = 1000;
  const STABLE_MS = 8000; // artifact unchanged this long ⇒ build finished
  const HARD_TIMEOUT_MS = 20 * 60 * 1000; // cold first-build library import ≈12 min

  const child = spawn(bin, args, { stdio: 'inherit', detached: true });
  let exited = false;
  let exitStatus = null;
  child.on('exit', (code) => { exited = true; exitStatus = code; });
  child.on('error', (e) => { exited = true; exitStatus = e && e.code === 'ENOENT' ? 127 : 1; });

  const start = Date.now();
  let lastSize = -1;
  let stableSince = 0;

  for (;;) {
    await sleep(POLL_MS);

    if (exited) return { status: exitStatus }; // editor exited on its own — normal path

    if (existsSync(ARTIFACT)) {
      let size = -1;
      try { size = statSync(ARTIFACT).size; } catch { /* mid-write */ }
      if (size > 0 && size === lastSize) {
        if (stableSince === 0) stableSince = Date.now();
        if (Date.now() - stableSince >= STABLE_MS) {
          console.warn(`[export] WATCHDOG: build artifact present & stable ${STABLE_MS}ms but editor still running — killing idle editor and continuing.`);
          killBuildGroup(child);
          return { status: 0 }; // build succeeded; the editor just refuses to exit
        }
      } else {
        stableSince = 0;
        lastSize = size;
      }
    }

    if (Date.now() - start >= HARD_TIMEOUT_MS) {
      console.error(`[export] WATCHDOG: hard timeout ${HARD_TIMEOUT_MS / 60000} min — killing editor; artifact ${existsSync(ARTIFACT) ? 'present' : 'MISSING'}.`);
      killBuildGroup(child);
      return { status: existsSync(ARTIFACT) ? 0 : 1 };
    }
  }
}

async function main() {
  const projectDir = resolveProjectDir();
  if (!existsSync(join(projectDir, 'project.json')) && !existsSync(join(projectDir, 'assets'))) {
    console.error(`[export] FATAL: no project.json / assets/ in ${projectDir} — not a Cocos Creator project.`);
    process.exit(1);
  }
  const isDebug = process.argv.includes('--debug');
  const distDir = resolve(projectDir, 'dist');
  // Cocos ALWAYS appends the platform name to buildPath, so buildPath=<distDir>
  // lands the web build at <distDir>/web-mobile/, never <distDir>/ directly.
  // We build there, then normalize the contents UP into dist/ so dist/index.html
  // is the canonical output every downstream tool (serve/selftest/eval) expects.
  const platformDir = join(distDir, 'web-mobile');
  const buildArg = `platform=web-mobile;debug=${isDebug ? 'true' : 'false'};buildPath=${distDir}`;

  const bin = findCocos();
  if (!bin) {
    console.error('──────────────────────────────────────────────────────────────');
    console.error('[export] BUILD-BLOCKED: the CocosCreator editor binary was not found.');
    console.error('  Cocos Creator is an EDITOR-centric engine (not an importable JS lib).');
    console.error('  Its editor (~2GB) compiles the TS components + scene into a web build.');
    console.error('  The game CODE in this scaffold (assets/scripts/*.ts, Main.scene) is');
    console.error('  COMPLETE and correct — only the editor toolchain is absent here.');
    console.error('');
    console.error('  Install: download Cocos Dashboard from https://www.cocos.com/en/creator');
    console.error('           then install Creator 3.8.x via the Dashboard.');
    console.error('  Or set COCOS_CREATOR=/path/to/CocosCreator.app/Contents/MacOS/CocosCreator');
    console.error('');
    console.error('  The command this script WOULD run once the editor is present:');
    console.error(`    CocosCreator --project "${projectDir}" --build "${buildArg}"`);
    console.error('──────────────────────────────────────────────────────────────');
    process.exit(3); // distinct exit code = build-blocked, not a code error
  }

  console.log(`[export] CocosCreator: ${bin}`);
  console.log(`[export] --build "${buildArg}"`);
  mkdirSync(distDir, { recursive: true });

  // Headless build. Cocos Creator runs Electron headless when given --project
  // + --build; it exits non-zero on real failures.
  const r = await runBuildWithWatchdog(bin, ['--project', projectDir, '--build', buildArg], platformDir);

  // Cocos writes to dist/web-mobile/. Normalize that UP into dist/ so the
  // canonical artifact is dist/index.html (what serve/selftest/eval expect).
  // A non-zero exit with a complete web-mobile/index.html present is the known
  // "metric-collector crashed after a successful build" case — treat as success.
  const platformIndex = join(platformDir, 'index.html');
  if (existsSync(platformIndex)) {
    if (r.status !== 0 && r.status !== null) {
      console.warn(`[export] WARN: CocosCreator exited ${r.status} but ${platformIndex} exists — normalizing & continuing.`);
    }
    for (const entry of readdirSync(platformDir)) {
      const src = join(platformDir, entry);
      const dst = join(distDir, entry);
      if (existsSync(dst)) rmSync(dst, { recursive: true, force: true });
      renameSync(src, dst);
    }
    rmSync(platformDir, { recursive: true, force: true });
  } else if (r.status !== 0 && r.status !== null) {
    console.error(`[export] FATAL: build failed (status ${r.status}); no web-mobile/index.html produced.`);
    process.exit(1);
  }

  if (!existsSync(join(distDir, 'index.html'))) {
    console.error('[export] FATAL: expected dist/index.html not found after build (no web-mobile/ output to normalize).');
    process.exit(1);
  }

  // Report what we produced.
  let totalBytes = 0;
  const walk = (d) => {
    for (const f of readdirSync(d)) {
      const p = join(d, f);
      const st = statSync(p);
      if (st.isDirectory()) walk(p);
      else totalBytes += st.size;
    }
  };
  try { walk(distDir); } catch { /* */ }
  console.log(`[export] dist/ — ${(totalBytes / 1e6).toFixed(2)} MB total (multi-file Cocos web-mobile build).`);
  console.log('[export] OK — serve with `node scripts/serve.mjs dist` then open http://127.0.0.1:8099/');
  process.exit(0);
}

main().catch((e) => { console.error('[export] FATAL:', e); process.exit(1); });
