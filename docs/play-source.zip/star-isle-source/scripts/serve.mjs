// ──────────────────────────────────────────────────────────────────────────
// serve.mjs — a tiny zero-dependency static file server for serving a Cocos
// Creator web-mobile build to Playwright.
//
// WHY THIS EXISTS: a Cocos Creator web-mobile build is MULTI-FILE (index.html +
// cocos-js bundle + system bundle + settings JSON + assets/) and CANNOT run
// from file:// — the browser blocks the cross-origin fetch of the sibling JS
// bundles + the JSON settings + the WASM physics blob. So, like the Godot
// export (and unlike the Babylon / Three-Rapier single-file IIFE builds), the
// Cocos harness MUST serve the build over HTTP.
//
// Cocos web-mobile is SINGLE-THREADED by default (no SharedArrayBuffer), so we
// do NOT need the COOP/COEP cross-origin-isolation headers. We send them anyway
// behind `--coop` for a future threads/wasm-physics build that wants them.
//
// Usable two ways:
//   1. Imported:  const srv = await serve(distDir); ... srv.close();
//   2. CLI:       node serve.mjs <dir> [--port N] [--coop]
// ──────────────────────────────────────────────────────────────────────────
import http from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { join, normalize, extname } from 'node:path';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.wasm': 'application/wasm',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.css': 'text/css; charset=utf-8',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.ttf': 'font/ttf',
  '.bin': 'application/octet-stream',
};

/**
 * Start a static server rooted at `dir`.
 * @param {string} dir absolute path to the build folder (contains index.html)
 * @param {{ port?: number, coop?: boolean }} opts
 * @returns {Promise<{ url: string, port: number, close: () => Promise<void> }>}
 */
export function serve(dir, opts = {}) {
  const coop = !!opts.coop;
  const port = opts.port || 0; // 0 → OS picks a free port
  const server = http.createServer((req, res) => {
    try {
      const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
      let rel = normalize(urlPath).replace(/^(\.\.[/\\])+/, '');
      if (rel === '/' || rel === '') rel = '/index.html';
      const filePath = join(dir, rel);
      if (!filePath.startsWith(dir) || !existsSync(filePath) || !statSync(filePath).isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('not found');
        return;
      }
      const headers = { 'Content-Type': MIME[extname(filePath)] || 'application/octet-stream' };
      if (coop) {
        headers['Cross-Origin-Opener-Policy'] = 'same-origin';
        headers['Cross-Origin-Embedder-Policy'] = 'require-corp';
        headers['Cross-Origin-Resource-Policy'] = 'cross-origin';
      }
      res.writeHead(200, headers);
      createReadStream(filePath).pipe(res);
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('server error: ' + (e && e.message));
    }
  });
  return new Promise((resolve, reject) => {
    server.on('error', reject);
    server.listen(port, '127.0.0.1', () => {
      const actual = server.address().port;
      resolve({
        url: `http://127.0.0.1:${actual}/index.html`,
        port: actual,
        close: () => new Promise((r) => server.close(() => r())),
      });
    });
  });
}

// CLI mode.
if (import.meta.url === `file://${process.argv[1]}`) {
  const dir = process.argv[2];
  if (!dir || !existsSync(dir)) {
    console.error('usage: node serve.mjs <build-dir> [--port N] [--coop]');
    process.exit(1);
  }
  const portIdx = process.argv.indexOf('--port');
  const port = portIdx !== -1 ? Number(process.argv[portIdx + 1]) : 8099;
  const coop = process.argv.includes('--coop');
  serve(dir, { port, coop }).then((srv) => {
    console.log(`[serve] ${srv.url}  (coop=${coop})  — Ctrl-C to stop`);
    process.on('SIGINT', () => srv.close().then(() => process.exit(0)));
  });
}
