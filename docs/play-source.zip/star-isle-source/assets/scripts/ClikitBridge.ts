// ──────────────────────────────────────────────────────────────────────────
// ClikitBridge.ts — the __CLIKIT__ window-contract bridge for Cocos Creator.
//
// Architecture: raw Cocos Creator nodes + components + the clikit thin harness.
// Templates own their Node / Sprite / Camera / Light / MeshRenderer / scripts
// directly — there is NO clikit wrapper around the Cocos scene graph. clikit
// owns ONLY the edges:
//   • build  → CocosCreator --project . --build "platform=web-mobile" (multi-file)
//   • assets → gen-assets.mjs (Gemini texture → assets/textures/<id>.png as a
//              Cocos sprite-frame / 2D-3D texture)
//   • eval   → eval.mjs (Gemini multimodal judge, mobile-casual-aware rubric)
//   • THIS FILE → the `window.__CLIKIT__` snapshot/report contract + the
//     `window.__CLIKIT_FEEL__` feel-signal counters.
//
// WHY THIS IS *SIMPLER* THAN GODOT:
//   Godot's clikit_bridge.gd has to cross a language boundary — GDScript calls
//   `JavaScriptBridge.eval("window.__CLIKIT__ = ...")` to install the contract,
//   then serializes a JSON string into a JS cache every frame and re-parses it
//   on the JS side. That round-trip (GDScript dict → JSON string → JS parse) is
//   the price of Godot's own VM.
//
//   Cocos game code IS JavaScript/TypeScript. There is NO language boundary.
//   This component writes `window.__CLIKIT__`, `window.__CLIKIT_FEEL__`, and
//   `window.__CLIKIT_SHAKE__` DIRECTLY — the snapshot object is the live JS
//   object the game already holds. No eval(), no JSON marshalling, no per-frame
//   re-parse. `__CLIKIT__.snapshot()` just reads the same live state the game
//   mutates. This is the most natural bridge of the four non-Phaser engines.
//
// USAGE FROM TEMPLATE CODE:
//   • ClikitBridge.instance.report(() => ({ score, level, ... }))  — register a
//     fn whose return is merged into snapshot() each call.
//   • ClikitBridge.feelParticles(n) / feelShake() / feelSound() / feelTween() /
//     feelHitstop() / feelMusic()  — bump the six cross-engine feel counters.
//   • ClikitBridge.instance.registerShakeHandler((i,d)=>{...})  — let the active
//     camera respond to __CLIKIT_SHAKE__ from JS (selftest) or from gameplay.
//
// The bridge is a Cocos `Component`; attach it to a persistent node in Main
// (it survives because Main is the only scene). On non-web platforms `window`
// is undefined, so every install is guarded.
// ──────────────────────────────────────────────────────────────────────────
import { _decorator, Component, director, game, Game } from 'cc';
const { ccclass } = _decorator;

export interface ClikitFeel {
  shakes: number;
  particles: number;
  sounds: number;
  tweens: number;
  hitstops: number;
  music: number;
}

type ReportFn = () => Record<string, unknown>;
type ShakeHandler = (intensity: number, durationMs: number) => void;

// Module-scoped singletons so the static feel* helpers work from anywhere
// (gameplay code may not have a node reference to the bridge component).
const _feel: ClikitFeel = { shakes: 0, particles: 0, sounds: 0, tweens: 0, hitstops: 0, music: 0 };
let _instance: ClikitBridge | null = null;

@ccclass('ClikitBridge')
export class ClikitBridge extends Component {
  static get instance(): ClikitBridge | null {
    return _instance;
  }
  static get feel(): ClikitFeel {
    return _feel;
  }

  // ── cross-engine feel bumpers (static so gameplay can call without a ref) ──
  static feelShake(intensity = 0.15, durationMs = 200): void {
    _feel.shakes++;
    const h = _instance?._shakeHandler;
    if (h) {
      try {
        h(intensity, durationMs);
      } catch {
        /* counting must never break the game */
      }
    }
  }
  static feelParticles(n = 1): void {
    _feel.particles += n;
  }
  static feelSound(n = 1): void {
    _feel.sounds += n;
  }
  static feelTween(n = 1): void {
    _feel.tweens += n;
  }
  static feelHitstop(n = 1): void {
    _feel.hitstops += n;
  }
  static feelMusic(n = 1): void {
    _feel.music += n;
  }

  private _reportFn: ReportFn | null = null;
  private _shakeHandler: ShakeHandler | null = null;
  private _frame = 0;
  private _fpsEma = 0;
  private _sceneKey = 'game';
  private _error: string | null = null;

  // ── public API for template / scene code ──
  report(fn: ReportFn): void {
    this._reportFn = fn;
  }
  setSceneKey(key: string): void {
    this._sceneKey = key;
  }
  setError(msg: string | null): void {
    this._error = msg;
  }
  registerShakeHandler(cb: ShakeHandler): void {
    this._shakeHandler = cb;
  }

  onLoad(): void {
    _instance = this;
    this._installContract();
  }

  onDestroy(): void {
    if (_instance === this) _instance = null;
  }

  // ── per-frame: keep the live snapshot fresh ──
  update(deltaTime: number): void {
    this._frame++;
    // fps as an EMA over the REAL per-frame delta — the honest render rate.
    // (Same lesson as Godot: a coarse 1-second fps bucket reads artificially
    // low right after a stall; an EMA over `deltaTime` is stable.)
    if (deltaTime > 0.0001) {
      const inst = 1 / deltaTime;
      this._fpsEma = this._fpsEma === 0 ? inst : this._fpsEma * 0.85 + inst * 0.15;
    }
  }

  private _nodeCount(): number {
    const scene = director.getScene();
    if (!scene) return 0;
    let n = 0;
    const walk = (node: { children?: unknown[] }): void => {
      n++;
      const kids = node.children;
      if (kids) for (const c of kids) walk(c as { children?: unknown[] });
    };
    try {
      walk(scene as unknown as { children?: unknown[] });
    } catch {
      /* */
    }
    return n;
  }

  // Build the live snapshot object the __CLIKIT__ contract returns. Because
  // game code runs in the same JS context, this needs NO marshalling.
  private _snapshot = (): Record<string, unknown> => {
    let extra: Record<string, unknown> = {};
    if (this._reportFn) {
      try {
        extra = this._reportFn() ?? {};
      } catch (e) {
        this._error = `report() threw: ${e instanceof Error ? e.message : String(e)}`;
      }
    }
    return {
      booted: true,
      scene: this._sceneKey,
      frame: this._frame,
      fps: Math.round(this._fpsEma),
      nodeCount: this._nodeCount(),
      error: this._error,
      feel: { ..._feel },
      ...extra,
    };
  };

  private _installContract(): void {
    const w = (globalThis as unknown as { window?: Record<string, unknown> }).window
      || (globalThis as Record<string, unknown>);
    if (!w || (w as Record<string, unknown>).__CLIKIT__) return;

    // The feel object IS the live module-scoped object — direct reference, no copy.
    (w as Record<string, unknown>).__CLIKIT_FEEL__ = _feel;

    // __CLIKIT_SHAKE__ bumps the JS counter (== the live _feel object) AND
    // drives the real Cocos camera through the registered handler. No flag
    // polling needed (unlike Godot) — the handler runs in the same JS turn.
    (w as Record<string, unknown>).__CLIKIT_SHAKE__ = (intensity = 0.15, duration = 200) => {
      ClikitBridge.feelShake(intensity, duration);
    };

    (w as Record<string, unknown>).__CLIKIT__ = {
      engine: 'cocos-creator',
      snapshot: this._snapshot,
    };

    // Mirror render-loop end so the snapshot always reflects the latest frame
    // even if a template forgets to keep `update` running (defensive).
    game.on(Game.EVENT_RESTART, () => {
      this._frame = 0;
      this._error = null;
    });

    // Surface uncaught errors into snapshot.error so eval/selftest can see them.
    // Typed loosely so this compiles whether or not the DOM lib is in scope.
    const realWindow = (globalThis as unknown as {
      window?: { addEventListener?: (t: string, cb: (e: unknown) => void) => void };
    }).window;
    if (realWindow && typeof realWindow.addEventListener === 'function') {
      realWindow.addEventListener('error', (e: unknown) => {
        const ev = e as { message?: string; error?: unknown };
        this._error = ev.message || String(ev.error);
      });
      realWindow.addEventListener('unhandledrejection', (e: unknown) => {
        this._error = `unhandledrejection: ${(e as { reason?: unknown }).reason}`;
      });
    }
  }
}
