import { _decorator,Component,Node,Camera,Color,director,Director,game,Label,Canvas,UITransform,Layers,view,Graphics,ResolutionPolicy,Vec3,tween } from 'cc';
import {ClikitBridge} from './ClikitBridge';
import {configFromSearch,fresh,drop,State,Config} from './GameLogic';
const {ccclass}=_decorator;
@ccclass('Main') export class Main extends Component {
 private cfg:Config=configFromSearch(globalThis.location?.search||''); private state:State=fresh(this.cfg); private root:Node; private tiles:Node; private score:Label;private moves:Label;private next:Label;private message:Label;private status:Label; private progress:Graphics;private bridge:ClikitBridge;private busy=false;private cells:{graphics:Graphics,label:Label}[][]=[];
 onLoad(){this.bridge=this.node.addComponent(ClikitBridge);}
 start(){
 view.setDesignResolutionSize(720,1280,ResolutionPolicy.SHOW_ALL);const scene=director.getScene();
 const cameraNode=new Node('UI Camera');cameraNode.layer=Layers.Enum.UI_2D;scene.addChild(cameraNode);cameraNode.setPosition(0,0,1000);const cam=cameraNode.addComponent(Camera);cam.projection=Camera.ProjectionType.ORTHO;cam.clearColor=this.color(this.cfg.theme==='garden'?'172D29':'141A31');cam.clearFlags=Camera.ClearFlag.SOLID_COLOR;cam.visibility=Layers.Enum.UI_2D;cam.near=1;cam.far=2000;
 this.root=new Node('Star Isle Canvas');scene.addChild(this.root);this.root.layer=Layers.Enum.UI_2D;this.root.addComponent(UITransform).setContentSize(720,1280);this.root.addComponent(Canvas).cameraComponent=cam;
 const stars=this.shape('stars',this.root,0,0);for(let i=0;i<48;i++){stars.fillColor=this.color(i%3?'34435B':'839C9C');stars.circle(((i*179)%690)-345,((i*283)%1240)-620,i%4===0?2:1);stars.fill();}
 this.label('ORIGINAL  ·  COCOS PLAY LAB',0,580,16,'9DADA7');this.label(this.cfg.title,0,519,Math.min(48,Math.floor(580/Math.max(1,this.cfg.title.length))),'F2EAD7');this.label(this.cfg.theme==='garden'?'让每一次相遇，长成新的花园':'让每一次相遇，点亮新的星屿',0,468,20,'A4B4BC');
 this.panel(-195,370,180,116,'25344C');this.panel(0,370,180,116,'25344C');this.panel(195,370,180,116,'3A3C45');
 this.label('累计得分',-195,403,17,'A4B4BC');this.score=this.label('0',-195,358,38,'F6E8C8');this.label('剩余步数',0,403,17,'A4B4BC');this.moves=this.label('40',0,358,38,'F6E8C8');this.label('下一枚',195,403,17,'BFC3B7');this.next=this.label('2',195,358,38,'E6C783');
 this.label('目标 '+this.cfg.goal+' 分',-205,279,19,'C8D5CF');this.label('点击任一列投放 ↓',151,279,19,'C8D5CF');
 this.panel(0,-12,602,548,'202B40');this.tiles=new Node('Tiles');this.root.addChild(this.tiles);this.tiles.layer=Layers.Enum.UI_2D;
 for(let c=0;c<4;c++){this.cells[c]=[];for(let r=0;r<5;r++){const x=-216+c*144,y=-224+r*106;this.cells[c][r]={graphics:this.panel(x,y,128,94,'2C394D',this.tiles).getComponent(Graphics),label:this.label('·',x,y,27,'4C6071',this.tiles)};}}
 for(let c=0;c<4;c++){const n=new Node('Column '+c);n.layer=Layers.Enum.UI_2D;this.root.addChild(n);n.setPosition(-216+c*144,-12,0);n.addComponent(UITransform).setContentSize(142,540);n.on(Node.EventType.TOUCH_END,()=>this.play(c),this);}
 this.progress=this.shape('progress',this.root,0,-315);this.status=this.label('',0,-363,22,'E6C783');this.message=this.label('相同数字相遇，合成两倍并计分',0,-408,20,'B3C2C3');
 this.label('优先合成：下 · 左 · 右 · 上   /   合成后自动下落',0,-446,16,'82969F');
 const reset=this.panel(0,-518,294,70,'C6DFC9');this.label('重新开始',0,-517,23,'203B36');reset.on(Node.EventType.TOUCH_END,()=>{this.state=fresh(this.cfg);this.message.string='新的星屿，从这一枚开始';this.render();},this);
 this.label('4 × 5 星盘   ·   2 / 4 随机投放   ·   无需付费',0,-593,15,'7F929D');
 this.bridge.setSceneKey('star-isle-merge');this.bridge.report(()=>({score:this.state.score,moves:this.state.moves,next:this.state.next,status:this.state.status,grid:this.state.grid.map(c=>[...c]),turns:this.state.turns,config:this.cfg}));
 (globalThis as any).__STAR_ISLE__={snapshot:()=>JSON.parse(JSON.stringify({state:this.state,config:this.cfg}))};this.render();
 }
 color(hex:string){return new Color(parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16),255);}
 shape(name:string,parent:Node,x:number,y:number){const n=new Node(name);n.layer=Layers.Enum.UI_2D;parent.addChild(n);n.setPosition(x,y);n.addComponent(UITransform).setContentSize(720,1280);return n.addComponent(Graphics);}
 panel(x:number,y:number,w:number,h:number,color:string,parent=this.root){const g=this.shape('panel',parent,x,y);g.node.getComponent(UITransform).setContentSize(w,h);g.fillColor=this.color(color);g.roundRect(-w/2,-h/2,w,h,20);g.fill();return g.node;}
 label(text:string,x:number,y:number,size:number,color:string,parent=this.root){const n=new Node('Text');n.layer=Layers.Enum.UI_2D;parent.addChild(n);n.setPosition(x,y);const l=n.addComponent(Label);l.string=text;l.fontSize=size;l.lineHeight=size*1.35;l.color=this.color(color);l.horizontalAlign=Label.HorizontalAlign.CENTER;l.verticalAlign=Label.VerticalAlign.CENTER;return l;}
 play(col:number){if(this.busy)return;const r=drop(this.state,col,this.cfg);if(!r.accepted){if(this.state.status==='playing')this.message.string='这一列已满，试试另一列';return;}this.message.string=r.merged?'连锁 '+r.merged+' 次  ·  +'+r.gain+' 分':'寻找相同数字，让星屿相遇';this.render();if(r.merged){this.busy=true;this.tiles.setScale(1.025,1.025,1);tween(this.tiles).to(.16,{scale:new Vec3(1,1,1)}).call(()=>this.busy=false).start();ClikitBridge.feelTween(1);}}
 render(){const palette=['A9D7C7','DFC995','A8C9E4','C6B8DE','E7AF9E','E8D079','A3DCE1'];for(let c=0;c<4;c++)for(let r=0;r<5;r++){const v=this.state.grid[c][r],cell=this.cells[c][r];cell.graphics.clear();cell.graphics.fillColor=this.color(v?palette[Math.min(6,Math.log2(v)-1)]:'2C394D');cell.graphics.roundRect(-64,-47,128,94,20);cell.graphics.fill();cell.label.string=v?String(v):'·';cell.label.fontSize=v?36:27;cell.label.lineHeight=cell.label.fontSize*1.35;cell.label.color=this.color(v?'263C40':'4C6071');}this.score.string=String(this.state.score);this.moves.string=String(this.state.moves);this.next.string=String(this.state.next);this.progress.clear();this.progress.fillColor=this.color('34455B');this.progress.roundRect(-278,-5,556,10,5);this.progress.fill();const w=Math.max(10,556*Math.min(1,this.state.score/this.cfg.goal));this.progress.fillColor=this.color('B9DCC6');this.progress.roundRect(-278,-5,w,10,5);this.progress.fill();this.status.string=this.state.status==='won'?'目标达成 · 星屿已点亮':this.state.status==='lost'?'本局结束 · 再试一次吧':this.state.score+' / '+this.cfg.goal+'  ·  合成点亮星盘';}
}
function boot(){const s=director.getScene();if(!s||s.getChildByName('ClikitBoot'))return;const n=new Node('ClikitBoot');s.addChild(n);n.addComponent(Main);}if(game)director.on(Director.EVENT_AFTER_SCENE_LAUNCH,boot);
