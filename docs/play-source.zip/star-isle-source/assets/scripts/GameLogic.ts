export type Config = { title:string; theme:string; moves:number; goal:number };
export type State = { grid:number[][]; score:number; moves:number; next:number; status:string; turns:number };
export function configFromSearch(search:string):Config {
 const q=new URLSearchParams(search);const m=q.get('moves')||'';const g=Number(q.get('goal'));
 return {title:(q.get('title')||'星屿合成').replace(/[<>\u0000-\u001f]/g,'').slice(0,24)||'星屿合成',theme:q.get('theme')==='garden'?'garden':'orbit',moves:/^\d+$/.test(m)&&Number(m)>=15&&Number(m)<=80?Number(m):40,goal:[64,128,256,512].includes(g)?g:256};
}
export function fresh(c:Config, rng= Math.random):State { return {grid:Array.from({length:4},()=>Array(5).fill(0)),score:0,moves:c.moves,next:rng()<.8?2:4,status:'playing',turns:0}; }
export function drop(s:State,col:number,c:Config,rng=Math.random):{accepted:boolean;merged:number;gain:number} {
 if(s.status!=='playing'||!Number.isInteger(col)||col<0||col>3||s.grid[col][4])return {accepted:false,merged:0,gain:0};
 let row=s.grid[col].findIndex(x=>x===0), activeCol=col; s.grid[col][row]=s.next;s.moves--;s.turns++;let merged=0,gain=0;
 for(let guard=0;guard<20;guard++) {
  const dirs=[[activeCol,row-1],[activeCol-1,row],[activeCol+1,row],[activeCol,row+1]];
  const hit=dirs.find(([x,y])=>x>=0&&x<4&&y>=0&&y<5&&s.grid[x][y]===s.grid[activeCol][row]);if(!hit)break;
  const [x,y]=hit;s.grid[x][y]=0;s.grid[activeCol][row]*=2;gain+=s.grid[activeCol][row];merged++;
  for(let cx=0;cx<4;cx++) {let dst=0;for(let ry=0;ry<5;ry++){if(!s.grid[cx][ry])continue;const v=s.grid[cx][ry];if(cx===activeCol&&ry===row)row=dst;s.grid[cx][dst++]=v;}while(dst<5)s.grid[cx][dst++]=0;}
 }
 s.score+=gain;s.next=rng()<.8?2:4;s.status=s.score>=c.goal?'won':s.moves<=0||s.grid.every(c=>c[4]!==0)?'lost':'playing';return {accepted:true,merged,gain};
}
